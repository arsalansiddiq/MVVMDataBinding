package com.raaziatariq.mvvmdatabinding.core.manager;

public class SharedPreferencesConstants {
    public static final String EMOM_PREFERENCES = "EmomPreferences";
}
