package com.raaziatariq.mvvmdatabinding.ui.splashactivity;

import android.arch.lifecycle.ViewModel;

import com.raaziatariq.mvvmdatabinding.core.manager.EmomSharedPreferences;
import com.raaziatariq.mvvmdatabinding.core.realm.RealmCRUD;
import com.raaziatariq.mvvmdatabinding.core.realm.table.DBModel;

import javax.inject.Inject;

public class SplashActivityViewModel extends ViewModel {
    EmomSharedPreferences emomSharedPreferences;


    @Inject
    public SplashActivityViewModel(EmomSharedPreferences emomSharedPreferences) {
        this.emomSharedPreferences = emomSharedPreferences;
    }

    int getDeviceId(){
        DBModel dbModel = new DBModel(1,"92442116599","fyfykvuk");
        return dbModel.getId();
    }
}
