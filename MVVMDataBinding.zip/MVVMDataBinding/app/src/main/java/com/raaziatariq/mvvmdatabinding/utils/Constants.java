package com.raaziatariq.mvvmdatabinding.utils;

public class Constants {
    public static final String BASE_URL = "";
}
