package com.raaziatariq.mvvmdatabinding.ui.trackingactivity;

import android.arch.lifecycle.ViewModel;

import com.raaziatariq.mvvmdatabinding.core.manager.EmomSharedPreferences;

import javax.inject.Inject;

public class TrackingActivityViewModel extends ViewModel {
        EmomSharedPreferences emomSharedPreferences;

    @Inject
    public TrackingActivityViewModel(EmomSharedPreferences emomSharedPreferences) {
            this.emomSharedPreferences = emomSharedPreferences;
        }
}
