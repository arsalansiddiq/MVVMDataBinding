package com.raaziatariq.mvvmdatabinding.core.network.retrofit;

public interface NetworkInterfaces {
}
