package com.raaziatariq.mvvmdatabinding.ui.trackingactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.raaziatariq.mvvmdatabinding.R;

public class TrackingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracking);
    }
}
